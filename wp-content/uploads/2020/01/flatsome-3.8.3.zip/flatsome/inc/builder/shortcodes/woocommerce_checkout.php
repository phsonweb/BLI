<?php

add_ux_builder_shortcode('woocommerce_checkout', array(
  'name' => __( 'WC Checkout' ),
  'hidden' => true
) );
